package com.cg.jpaspring.service;


public interface ICustomerService {



	void deposit(int id, double balance);
	
}
