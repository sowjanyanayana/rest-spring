package com.cg.jpaspring.dao;


public interface ICustomerDao {




	void deposit(int id, double balance);
	
}
