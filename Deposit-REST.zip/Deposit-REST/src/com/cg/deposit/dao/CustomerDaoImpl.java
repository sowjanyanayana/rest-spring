package com.cg.deposit.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.deposit.bean.Customer;


@Repository("dao")
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	EntityManager em;
	public  String deposit(int id, double amount) {
		Customer customer=null;
		String s1=null;
	Double balance=0.00;
	if(amount>0) 
	{
		customer=em.find(Customer.class, id);
		if(customer!=null){
		balance=customer.getBalance()+amount;
		customer.setBalance(balance);	
		em.merge(customer);
		em.flush();
		s1="updated balance :"+balance.toString();
		return s1;
		}
		else
		{
			return "id doesn't exist";
		}
	}
	else
		return "check the amount";
	}

}
