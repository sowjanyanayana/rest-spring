package com.cg.deposit.dao;

public interface ICustomerDao {
	public String deposit(int id, double amount);

}
