package com.cg.deposit.service;

public interface ICustomerService {
	
	public String deposit(int id, double amount);

}
