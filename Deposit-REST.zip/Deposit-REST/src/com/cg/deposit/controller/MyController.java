package com.cg.deposit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.deposit.service.ICustomerService;



/*@CrossOrigin(origins = "http://localhost:8082")*/
@RestController
public class MyController {
	@Autowired
	ICustomerService service;
	
	@RequestMapping(value ="customer/deposit/id/{id}/amount/{amount}",headers="Accept=*/*",method = RequestMethod.GET)
	public String deposit(@PathVariable("id") int id,@PathVariable("amount") double amount) {

		String string=service.deposit(id, amount);

		return string;

	}
	
	 
}
